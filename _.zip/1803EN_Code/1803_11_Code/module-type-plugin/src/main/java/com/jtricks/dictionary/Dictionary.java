package com.jtricks.dictionary;

public interface Dictionary {
	String getDefinition(String text);
}
