package com.jtricks.provider;

public interface MyComponent {
	
	public void doSomething();

}
